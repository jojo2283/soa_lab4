package com.example.backendfilms.model;

public enum MovieGenre {
    ACTION,
    ADVENTURE,
    TRAGEDY,
    FANTASY
}
