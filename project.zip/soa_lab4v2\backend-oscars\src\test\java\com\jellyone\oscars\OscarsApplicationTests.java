package com.jellyone.oscars;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OscarsApplicationTests {

    @Test
    void contextLoads() {
    }
}


