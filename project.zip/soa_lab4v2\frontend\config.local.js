// Локальная конфигурация для разработки
module.exports = {
  moviesApiUrl: 'http://localhost:8080',
  oscarsApiUrl: 'http://localhost:8081',
  environment: 'development'
}
