package com.example.backendfilms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;




@SpringBootApplication
public class BackendfilmsApplication {

    public static void main(String[] args) {
        SpringApplication.run(BackendfilmsApplication.class, args);
    }

}
