// Продакшн конфигурация для сервера
module.exports = {
    // moviesApiUrl: 'https://se.ifmo.ru/~s367268/movies-api',
    // oscarsApiUrl: 'https://se.ifmo.ru/~s367268/oscars-api',
    moviesApiUrl: 'http://localhost:8080',
    oscarsApiUrl: 'http://localhost:8081',
    environment: 'production'
}
