rootProject.name = "backend-oscars"


